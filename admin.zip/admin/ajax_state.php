<?php
// Establish Connection with MYSQL
$con = mysql_connect ("localhost","root");
// Select Database
mysql_select_db("homelands", $con);
if($_POST['StateName'])
{
$id=$_POST['StateName'];
$sql=mysql_query("select * from County where StateName='$id' ");
echo '<option selected="selected">--Select State--</option>';
while($row=mysql_fetch_array($sql))
{
echo '<option value="'.$row['CountyName'].'">'.$row['CountyName'].'</option>';
}
}

?>