	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
<li><a href="#"><i class="fa fa-files-o"></i> House Types</a>
<ul>
<li><a href="create-House.php">Create House</a></li>
<li><a href="manage-Listing_Types.php">Manage Listing_Types</a></li>
</ul>
</li>

<li><a href="#"><i class="fa fa-sitemap"></i> Houses</a>
					<ul>
						<li><a href="post-aHouse.php">Post a House</a></li>
						<li><a href="manage-Houses.php">Manage Houses</a></li>
					</ul>
				</li>
				<li><a href="manage-bookings.php"><i class="fa fa-users"></i> Manage Booking</a></li>

				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop"> </i> Manage Conatctus Query</a></li>
				<div class="leftpannel">
   <div class="find">
          <div class="leftpan1"></div>
          <div class="leftpan2">
            <div class="leftmenu">
              <ul>
                <li><a href="dashboard.php">Manage Landlords</a></li>
                <li><a href="State.php">Manage State</a></li>
                <li><a href="County.php">Manage County</a></li>
                <li><a href="Area.php">Manage Area</a></li>
                <li><a href="Category.php">Manage Category</a></li>
                <li><a href="Feedback.php">Feedback</a></li>
                 
              </ul>
            </div>
          </div>
        </div>
  <div >
 
  <table border="0" width="100%">
  <tr>
    <td height="28" bgcolor="#999999"><div align="center"><span class="style11">Reports</span></div></td>
  </tr>
  <tr>
  <td><a href="LandlordReport.php" target="_blank" class="style14">Landlord Report</a></td>
  </tr>
   
   <tr>
  <td><span class="style15"><a href="NewsReport.php" target="_blank" class="style14">News Report</a></span></td>
  </tr>
   <tr>
  <td><span class="style15"><a href="PropertyReport.php" target="_blank" class="style14">Property Report</a></span></td>
  </tr>
  </table>
				<li><a href="reg-users.php"><i class="fa fa-users"></i>TENANTS</a></li>
				<li><a href="manage-bookings.php"><i class="fa fa-users"></i> Manage Booking</a></li>
			<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li>
			<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Update Contact Info</a></li>

			<li><a href="manage-subscribers.php"><i class="fa fa-table"></i> Manage Subscribers</a></li>

			</ul>
		</nav>