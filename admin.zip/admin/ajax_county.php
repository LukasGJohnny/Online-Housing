<?php
// Establish Connection with MYSQL
$con = mysql_connect ("localhost","root");
// Select Database
mysql_select_db("homelands", $con);
if($_POST['CountyName'])
{
$id=$_POST['CountyName'];
$sql=mysql_query("select * from Area_tbl where CountyName='$id' ");
echo '<option selected="selected">--Select County--</option>';
while($row=mysql_fetch_array($sql))
{
echo '<option value="'.$row['AreaName'].'">'.$row['AreaName'].'</option>';
}
}

?>