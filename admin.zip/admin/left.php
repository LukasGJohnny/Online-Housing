<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style11 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: small;
	color: #FFFFFF;
}
.style14 {font-size: small; font-family: Verdana, Arial, Helvetica, sans-serif; color: #000033; }
.style15 {color: #000033}
-->
</style>
<div class="leftpannel">
   <div class="find">
          <div class="leftpan1"></div>
          <div class="leftpan2">
            <div class="leftmenu">
              <ul>
			  <li><a href="dashboard.php">DASHBOARD</a></li>
                <li><a href="User.php">Manage Landlords</a></li>
                <li><a href="State.php">Manage State</a></li>
                <li><a href="County.php">Manage County</a></li>
                <li><a href="Area.php">Manage Area</a></li>
                <li><a href="Category.php">Manage Category</a></li>
                <li><a href="Feedback.php">Feedback</a></li>
                 
              </ul>
            </div>
          </div>
        </div>
  <div >
 
  <table border="0" width="100%">
  <tr>
    <td height="28" bgcolor="#999999"><div align="center"><span class="style11">Reports</span></div></td>
  </tr>
  <tr>
  <td><a href="LandlordReport.php" target="_blank" class="style14">Landlord Report</a></td>
  </tr>
   
   <tr>
  <td><span class="style15"><a href="NewsReport.php" target="_blank" class="style14">News Report</a></span></td>
  </tr>
   <tr>
  <td><span class="style15"><a href="PropertyReport.php" target="_blank" class="style14">Property Report</a></span></td>
  </tr>
  </table>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
    
  </div>
        
      </div>

