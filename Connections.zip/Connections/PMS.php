<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_homelands = "localhost";
$database_homelands = "homelands";
$username_homelands = "root";
$password_homelands = "";
$homelands = mysql_pconnect($hostname_homelands, $username_homelands, $password_homelands) or trigger_error(mysql_error(),E_USER_ERROR); 
?>